###############################################
README GENERAL DE LA TAREA 3
###############################################

Se adjuntan los archivos A.txt, b,txt A3.txt y b3.txt donde A es la matriz proporcionada por los ayudantes y
A3 es una matriz de 5x5 creada por mi, esta matriz fue usada de prueba y es la encargada de generar los archivos
llamados soluciones.txt, los archivos soluciones_BIG.txt corresponden a las soluciones generadas por los métodos
para la Matriz A y el vector b
